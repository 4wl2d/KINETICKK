# Android physical-device performance

Overall status: **ok**.

Source `feature-final4-telemetry` at `20a3e2f78988419f5263247085a9a4b3900f4a6e` (dirty: `true`); APK SHA-256 `ae18ba15339c9276ccbefddb0bcdce86c39f6df9eb761b73dd76fd484c394c25`.

Protocol: 3 process-cold forks per device; selector-only flow `kinetickk-gameplay-telemetry-touch-v1`; minimum 30 valid frames per fork.

Each device row is an independent same-serial aggregate with its own active-refresh frame budget. Raw frame counts are retained only inside that device's evidence and are never compared across devices.

| Device | API | Hz / budget ms | Cold p50 ms | Full-flow platform janky / p50 / p95 / p99 ms | Terminal deadline miss / overrun p95 ms | Completion latency p50 / p95 / p99 ms | UI submission p50 / p95 / p99 ms | Completion >1 / >2 refresh | Produced / presented FPS | Produced / presented cadence missed-vsync | PSS p50 MiB | Status |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| `Xiaomi Redmi Note 9 Pro` | 31 | 60.00 / 16.67 | 413.00 | 78.05% / 32.00 / 40.00 / 48.00 | 100.00% / 8.71 | 40.61 / 42.05 / 45.59 | 3.30 / 7.91 / 12.36 | 100.00% / 100.00% | 59.85 / n/a | 0.00% / unavailable | 102.86 | ok |

## Per-device evidence

### Xiaomi Redmi Note 9 Pro (`c91ae939`)

Android 12 / API 31; navigation `three-button`; battery 100%; status `ok`.

Within this serial only: the full-flow gfxinfo summary covers 4446 frames; the terminal steady-state ring retains 354 samples across 3 forks at 60.00 Hz.

Presented cadence unavailable (`column-present-all-unset`): DisplayPresentTime is zero/unset for every valid frame on this platform.

## Interpretation contract

- A process-cold start force-stops only this package; it does not clear app data, reset compilation, reboot the device, or flush filesystem caches.
- Full-flow platform janky frames and percentiles come from the complete `dumpsys gfxinfo` summary accumulated after the reset. Terminal latency/cadence/deadline evidence comes only from the bounded final framestats ring after the flow's steady-state tail.
- `FrameCompleted - IntendedVsync` is completion latency. Crossing one or two active-refresh periods is reported as a completion overrun, not as jank.
- On API 31+, terminal jank is strictly `FrameCompleted > FrameDeadline`; the positive difference is the completion-deadline overrun. API 30 reports terminal deadline jank as unavailable/null rather than inferring it.
- Produced cadence uses neighboring `IntendedVsync`; presented cadence uses neighboring `DisplayPresentTime` only when the platform populates it. An entirely zero/unset column is explicitly unavailable; mixed internal gaps fail closed. Each neighboring interval is rounded to active-refresh periods; periods beyond the first are cadence missed-vsync opportunities.
- Installation uses `adb install -r -t --no-incremental`, preserving app data. No uninstall, data clear, refresh-rate override, navigation change, rotation change, battery override, or other global setting mutation is performed.
- Compare branches only on the same serial, flow, APK variant, active refresh rate, thermal state, charging state, and fork count.
