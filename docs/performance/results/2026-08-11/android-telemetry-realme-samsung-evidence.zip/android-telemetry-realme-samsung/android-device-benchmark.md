# Android physical-device performance

Overall status: **ok**.

Source `feature-final2-telemetry` at `20a3e2f78988419f5263247085a9a4b3900f4a6e` (dirty: `true`); APK SHA-256 `ae18ba15339c9276ccbefddb0bcdce86c39f6df9eb761b73dd76fd484c394c25`.

Protocol: 3 process-cold forks per device; selector-only flow `kinetickk-gameplay-telemetry-touch-v1`; minimum 30 valid frames per fork.

Each device row is an independent same-serial aggregate with its own active-refresh frame budget. Raw frame counts are retained only inside that device's evidence and are never compared across devices.

| Device | API | Hz / budget ms | Cold p50 ms | Full-flow platform janky / p50 / p95 / p99 ms | Terminal deadline miss / overrun p95 ms | Completion latency p50 / p95 / p99 ms | UI submission p50 / p95 / p99 ms | Completion >1 / >2 refresh | Produced / presented FPS | Produced / presented cadence missed-vsync | PSS p50 MiB | Status |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| `realme RMX2002` | 30 | 60.00 / 16.67 | 447.00 | 29.09% / 9.00 / 14.00 / 17.00 | unavailable / unavailable | 9.49 / 12.42 / 14.36 | 2.75 / 4.31 / 5.24 | 0.00% / 0.00% | 60.12 / n/a | 0.00% / unavailable | 72.91 | ok |
| `samsung SM-A325F` | 33 | 90.00 / 11.11 | 556.00 | 58.34% / 21.00 / 36.00 / 38.00 | 34.45% / 5.61 | 16.96 / 27.20 / 28.21 | 6.03 / 9.54 / 12.46 | 100.00% / 33.89% | 89.97 / 89.98 | 0.00% / 0.00% | 82.90 | ok |

## Per-device evidence

### realme RMX2002 (`NVYXIJQGTOMVNZZH`)

Android 11 / API 30; navigation `three-button`; battery 100%; status `ok`.

Within this serial only: the full-flow gfxinfo summary covers 3094 frames; the terminal steady-state ring retains 360 samples across 3 forks at 60.00 Hz.

### samsung SM-A325F (`R58R603CSEY`)

Android 13 / API 33; navigation `three-button`; battery 100%; status `ok`.

Within this serial only: the full-flow gfxinfo summary covers 3855 frames; the terminal steady-state ring retains 357 samples across 3 forks at 90.00 Hz.

## Interpretation contract

- A process-cold start force-stops only this package; it does not clear app data, reset compilation, reboot the device, or flush filesystem caches.
- Full-flow platform janky frames and percentiles come from the complete `dumpsys gfxinfo` summary accumulated after the reset. Terminal latency/cadence/deadline evidence comes only from the bounded final framestats ring after the flow's steady-state tail.
- `FrameCompleted - IntendedVsync` is completion latency. Crossing one or two active-refresh periods is reported as a completion overrun, not as jank.
- On API 31+, terminal jank is strictly `FrameCompleted > FrameDeadline`; the positive difference is the completion-deadline overrun. API 30 reports terminal deadline jank as unavailable/null rather than inferring it.
- Produced cadence uses neighboring `IntendedVsync`; presented cadence uses neighboring `DisplayPresentTime` when the platform supplies it. Each neighboring interval is rounded to active-refresh periods; periods beyond the first are cadence missed-vsync opportunities.
- Installation uses `adb install -r -t --no-incremental`, preserving app data. No uninstall, data clear, refresh-rate override, navigation change, rotation change, battery override, or other global setting mutation is performed.
- Compare branches only on the same serial, flow, APK variant, active refresh rate, thermal state, charging state, and fork count.
